import sys
import os
import traceback
import time

# --- LOGGING SETUP ---
LOG_FILE = '/sdcard/boxcounter_log.txt'

class Logger(object):
    def __init__(self):
        self.terminal = sys.stdout
        self.log = open(LOG_FILE, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        self.terminal.flush()
        self.log.flush()

# Redirect stdout and stderr
try:
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE) # Start fresh each run
    
    sys.stdout = Logger()
    sys.stderr = sys.stdout
    print("--- APP STARTUP ---")
except Exception as e:
    # Fallback if we can't write to sdcard (permission issues?)
    print(f"CRITICAL: Cannot setup logging to {LOG_FILE}: {e}")

# --- REMOTE DEBUGGING SETUP ---
print("Attempting to import debugpy...")
try:
    import debugpy
    print("debugpy imported successfully.")
    
    # Listen on all interfaces
    print("debugpy listening on 0.0.0.0:5678...")
    debugpy.listen(('0.0.0.0', 5678))
    
    print("WAITING FOR DEBUGGER ATTACHMENT...")
    debugpy.wait_for_client()
    print("Debugger attached! Resuming...")
    
except ImportError:
    print("WARNING: debugpy not found. Skipping remote debug wait.")
except Exception as e:
    print(f"ERROR: Failed to start debugpy: {e}")
    traceback.print_exc()

# --- SAFE IMPORTS ---
print("Starting imports...")
try:
    from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.image import Image
    from kivy.clock import Clock
    from kivy.graphics.texture import Texture
    from kivy.core.window import Window
    from android_permissions import check_camera_permission
    import cv2
    import numpy as np
    
    # Import logic modules
    from logic import BoxFlowAnalyzer
    from config import Config
    
    print("Imports successful.")
except Exception as e:
    print("CRITICAL IMPORT ERROR:")
    traceback.print_exc()
    # We allow the app to crash here essentially, but at least it's logged.
    # To keep the app 'alive' to see the log, we could run a dummy loop, 
    # but buildozer/kivy might need the App class.
    sys.exit(1)


# --- WIDGET LOGIC ---
class CameraWidget(Image):
    def __init__(self, capture, analyzer, **kwargs):
        super(CameraWidget, self).__init__(**kwargs)
        self.capture = capture
        self.analyzer = analyzer
        self.fps = 30
        Clock.schedule_interval(self.update, 1.0 / self.fps)

    def update(self, dt):
        try:
            ret, frame = self.capture.read()
            if ret:
                # Process Frame
                processed_frame = self.analyzer.process_frame(frame)
                if processed_frame is None: return

                # Convert to Kivy Texture
                buf = cv2.flip(processed_frame, 0)
                buf = buf.tostring()
                
                # Update texture
                texture1 = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
                texture1.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
                self.texture = texture1
        except Exception as e:
            print(f"Error in CameraWidget.update: {e}")
            traceback.print_exc()

# --- APP LOGIC ---
class BoxCounterApp(App):
    def build(self):
        print("Building App UI...")
        try:
            # 1. Request Permissions
            print("Checking permissions...")
            check_camera_permission()
            
            # 2. Setup Camera
            print("Initializing Camera...")
            self.capture = cv2.VideoCapture(Config.CAMERA_ID)
            self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, Config.FRAME_WIDTH)
            self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, Config.FRAME_HEIGHT)
            self.capture.set(cv2.CAP_PROP_AUTOFOCUS, Config.AUTOFOCUS_VAL)
            
            if not self.capture.isOpened():
                print("WARNING: Camera failed to open!")

            # 3. Setup Logic
            print("Initializing BoxFlowAnalyzer...")
            self.analyzer = BoxFlowAnalyzer()

            # 4. Setup UI
            layout = BoxLayout(orientation='vertical')
            self.cam_widget = CameraWidget(self.capture, self.analyzer)
            layout.add_widget(self.cam_widget)
            
            print("App UI build passed.")
            return layout
        except Exception as e:
            print("CRITICAL ERROR IN APP BUILD:")
            traceback.print_exc()
            return None

    def on_stop(self):
        try:
            if hasattr(self, 'capture') and self.capture:
                self.capture.release()
        except Exception:
            pass

if __name__ == '__main__':
    try:
        BoxCounterApp().run()
    except Exception as e:
        print("CRITICAL UNCAUGHT EXCEPTION:")
        traceback.print_exc()
